﻿using AutoMapper;
using NZWalws.API.Models.Domain;
using NZWalws.API.Models.DTO;

namespace NZWalws.API.Mappings
{
    public class AutoMapperProfieles: Profile
    {
        public AutoMapperProfieles()
        {
            //Primo valore è quello di partenza Secondo Di destinazione
            CreateMap<Region, RegionDTO>().ReverseMap();
            CreateMap<AddRegionDto, Region>().ReverseMap();
            CreateMap<UpdateDto, Region>().ReverseMap();
            CreateMap<AddNewWalk, Walk>().ReverseMap();
            CreateMap<Walk, WalkDto>().ReverseMap();
            CreateMap<Difficulty, DifficultiesDto>().ReverseMap();
            CreateMap<UpdateWalkDto, Walk>().ReverseMap();

        }
    }
}
