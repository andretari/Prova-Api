﻿using System.ComponentModel.DataAnnotations.Schema;

namespace NZWalws.API.Models.DTO
{
    public class ImageUploadDto
    {
        [NotMapped]
        public IFormFile File { get; set; }
        [NotMapped]
        public string FileName { get; set; } = string.Empty;
        public string? FileDescription { get; set; }
    }
}
