﻿using System.ComponentModel.DataAnnotations;

namespace NZWalws.API.Models.DTO
{
    public class AddNewWalk
    {
        [Required]
        [MaxLength(50, ErrorMessage ="Il campo nome deve contenere massimo 50 caratteti")]
        public string Name { get; set; } = string.Empty;
        [Required]
        [MaxLength(1000, ErrorMessage = "Il campo descrizione deve contenere massimo 1000 caratteti")]
        public string Description { get; set; } = string.Empty;
        [Required]
        [Range(0,50,ErrorMessage ="Il campo Km deve avere un numero compreso tra 0 e 50")]
        public double LengthInKm { get;  set; }
        public string? WalkImageUrl { get; set; } = string.Empty;
        [Required]
        public Guid DifficultyId { get; set; }
        [Required]
        public Guid RegionId { get; set; }
    }
}
