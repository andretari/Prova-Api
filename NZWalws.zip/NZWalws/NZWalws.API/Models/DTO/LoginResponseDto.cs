﻿using Microsoft.IdentityModel.JsonWebTokens;

namespace NZWalws.API.Models.DTO
{
    public class LoginResponseDto
    {
       public string JwtToken { get; set; } = string.Empty;
    }
}
