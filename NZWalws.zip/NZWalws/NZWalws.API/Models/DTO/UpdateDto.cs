﻿using System.ComponentModel.DataAnnotations;

namespace NZWalws.API.Models.DTO
{
    public class UpdateDto
    {
        [Required]
        [MaxLength(3, ErrorMessage = "Code has to be a maximum of 3 characters")]
        [MinLength(3, ErrorMessage = "Code has to be a Minimun of 3 characters")]
        public string Code { get; set; } = string.Empty;

        [Required]
        [MaxLength(50, ErrorMessage = "Name has to be a maximum of 50 characters")]
        public string Name { get; set; } = string.Empty;
        public string? RegoionImageUrl { get; set; }
    }
}
