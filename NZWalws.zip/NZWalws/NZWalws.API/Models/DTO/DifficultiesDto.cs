﻿namespace NZWalws.API.Models.DTO
{
    public class DifficultiesDto
    {
        public Guid Id { get; set; }

        public string Name { get; set; } = string.Empty;
    }
}
