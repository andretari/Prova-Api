﻿using System.ComponentModel.DataAnnotations;

namespace NZWalws.API.Models.DTO
{
    public class RegisterRequestDto
    {
        [Required(ErrorMessage ="Campo Username è obbligatorio")]
        [DataType(DataType.EmailAddress)]
        public string Username { get; set; }

        [Required(ErrorMessage = "Campo Password è obbligatorio")]
        [MinLength(6, ErrorMessage ="Campo Password deve contenere almeno 6 caratteri")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        public string[] Roles { get; set; }
    }
}
