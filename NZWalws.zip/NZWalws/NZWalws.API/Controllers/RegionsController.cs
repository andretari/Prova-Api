﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NZWalws.API.CustomActionFilters;
using NZWalws.API.Data;
using NZWalws.API.Models.Domain;
using NZWalws.API.Models.DTO;
using NZWalws.API.Repositories.Interfaces;
using System.Diagnostics.Eventing.Reader;
using System.Net;
using System.Text.Json;

namespace NZWalws.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class RegionsController : ControllerBase
    {
        private readonly IRegionRepository regionRepository;
        private readonly IMapper mapper;
        private readonly ILogger<RegionsController> logger;

        public RegionsController(IRegionRepository regionRepository, IMapper mapper, ILogger<RegionsController> logger)
        {

            this.regionRepository = regionRepository;
            this.mapper = mapper;
            this.logger = logger;
        }

        [HttpGet]
        //[Authorize(Roles ="Reader,Writer")]
        public async Task<IActionResult> GetAllRegions([FromQuery] string? colonna, [FromQuery] string? ricerca, [FromQuery] string? colonnaOrdinamento, [FromQuery] bool? ordinamento, [FromQuery] int pagina = 1, [FromQuery] int elementiPagina = 10000)
        {

            //logger.LogInformation("GetAll Action Regions Method was invoked");

            var regions = await regionRepository.GetAllRegionsAsync(colonna, ricerca, colonnaOrdinamento, ordinamento ?? true, pagina, elementiPagina);
            var regionsDto = mapper.Map<List<RegionDTO>>(regions);

            //CReate exception

            //logger.LogInformation($"GetAll Action Regions finish with data: {JsonSerializer.Serialize(regionsDto)}");

            return Ok(regionsDto);
        }

        //[HttpGet]
        //public async Task<IActionResult> GetAllRegionsAsync()
        //{
        //    try
        //    {
        //        throw new Exception("errore");
        //        var regions = await regionRepository.GetAllRegionsAsync();
        //        var regionsDTO = mapper.Map<List<Region>>(regions);

        //        return Ok(regionsDTO);
        //    }
        //    catch (Exception ex)
        //    {
        //        return Problem("Qualcosa è andato storto", ex.Message, (int)HttpStatusCode.InternalServerError);
        //    }

        //}

        [HttpGet]
        //[Authorize(Roles = "Reader,Writer")]
        [Route("{id:Guid}")]
        public async Task<IActionResult> GetRegionById([FromRoute] Guid id)
        {
            var regions = await regionRepository.GetRegionByIdAsync(id);
            //var regions = dbContext.Regions.FirstOrDefault( x => x.Id == id);
            //Map Domain models in DTO
            if (regions == null)
            {
                return NotFound("Non esiste nessuna regione con questo id");
            }
            var regionsDto = mapper.Map<RegionDTO>(regions);
            return Ok(regionsDto);
        }

        [HttpPost]
        //[Authorize(Roles = "Writer")]
        [ValidateModel]
        public async Task<IActionResult> CreateANewRegion([FromBody] AddRegionDto regionDtoRequest)
        {
            //Map or convert DTO in to model domain 
            var region = mapper.Map<Region>(regionDtoRequest);

            //Add Region from Domain Model

            region = await regionRepository.CreateANewRegionAsync(region);

            //Poiche nella risposta di ritorno non possiamo fornire il modello domain
            // Riconvertiamo tutto al dto
            var regionDto = mapper.Map<RegionDTO>(region);

            return CreatedAtAction(nameof(GetRegionById), new { id = regionDto.Id }, regionDto);
        }

        [HttpPut]
        [Route("{id:Guid}")]
        [ValidateModel]
        //[Authorize(Roles = "Writer")]
        public async Task<IActionResult> UpdateRegion([FromRoute] Guid id, [FromBody] UpdateDto updateDto)
        {

            //Map dto to Domain Model
            var region = mapper.Map<Region>(updateDto);

            // check region esiste 
            region = await regionRepository.UpdateRegionAsync(id, region);

            if (region == null)
            {
                return NotFound("Id non esistente");
            }

            // Convert in DTo from Domain Model
            var regionDto = mapper.Map<RegionDTO>(region);

            return Ok(regionDto);
        }

        [HttpDelete]
        [Route("{id:guid}")]
        //[Authorize(Roles = "Writer")]
        public async Task<IActionResult> DeleteRegion([FromRoute] Guid id)
        {
            var region = await regionRepository.DeleteRegionAsync(id);
            if (region == null)
            {
                return NotFound("id non esistente");
            }

            // Convert in DTo from Domain Model
            var regionDto = mapper.Map<RegionDTO>(region);
            return Ok("Regione " + regionDto.Name + " eliminata correttamente");
        }
    }
}
