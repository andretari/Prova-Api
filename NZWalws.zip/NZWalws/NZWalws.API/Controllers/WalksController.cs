﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NZWalws.API.CustomActionFilters;
using NZWalws.API.Mappings;
using NZWalws.API.Models.Domain;
using NZWalws.API.Models.DTO;
using NZWalws.API.Repositories.Interfaces;

namespace NZWalws.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WalksController : ControllerBase
    {
        private readonly IMapper mapper;
        private readonly IWalksRepository walksRepository;

        public WalksController(IMapper mapper, IWalksRepository walksRepository)
        {
            this.mapper = mapper;
            this.walksRepository = walksRepository;
        }
        //Create
        [HttpPost]
        [ValidateModel]
        public async Task<IActionResult> CreateWalkAsync([FromBody] AddNewWalk addNewWalk)
        {
            var walk = mapper.Map<Walk>(addNewWalk);
            walk = await walksRepository.CreateWalkAsync(walk);
            var walkDto = mapper.Map<WalkDto>(walk);
            return Ok(walkDto);
        }

        //GetAll
        [HttpGet]
        public async Task<IActionResult> GettAllWalksAsync([FromQuery] string? filterOn, [FromQuery] string? filterQuery, [FromQuery] string? sortBy, [FromQuery] bool? ascending, [FromQuery] int pageNumber = 1, [FromQuery] int elemntiPagina = 1000)
        {
            var walks = await walksRepository.GetAllWalksAsync(filterOn,filterQuery,sortBy, ascending ?? true, pageNumber, elemntiPagina);
            var walksDTO = mapper.Map<List<WalkDto>>(walks);
            if(walks == null)
            {
                return NotFound("Nessun elemento trovato");
            }
            return Ok(walksDTO);
        }

        // Get by Id
        [HttpGet]
        [Route("{id:Guid}")]
        public async Task<IActionResult> GetWalkByIdAsync([FromRoute] Guid id)
        {
            var walk = await walksRepository.GetWalkByIdAsync(id);
            if (walk == null)
            {
                return NotFound();
            }
            var walkDto = mapper.Map<WalkDto>(walk);
            return Ok(walkDto);
        }

        //Update walk
        [HttpPut]
        [Route("{id:guid}")]
        [ValidateModel]
        public async Task<IActionResult> UpdateWalkByIdAsync([FromRoute] Guid id, [FromBody] UpdateWalkDto addWalkDto)
        {
            var walk = mapper.Map<Walk>(addWalkDto);
            walk = await walksRepository.UpdateWalkByIdAsync(id, walk);
            if (walk == null)
            {
                return NotFound();
            }
            var WalkDto = mapper.Map<WalkDto>(walk);
            return Ok(WalkDto.Name + " è stato aggiornato correttamente.");
        }

        //Delete Walk
        [HttpDelete]
        [Route("{id:Guid}")]
        public async Task<IActionResult> DeleteWalkByIdAsync([FromRoute] Guid id)
        {
            var walk = await walksRepository.DeleteWalkByIdAsync(id);
            if (walk == null)
            {
                return NotFound();
            }
            var walkDto = mapper.Map<WalkDto>(walk);
            return Ok(walkDto.Name + " eliminato corettamente");
        }
    }
}
