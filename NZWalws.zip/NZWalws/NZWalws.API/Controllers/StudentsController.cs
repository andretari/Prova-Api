﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace NZWalws.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetAllStudents()
        {
            string[] name = { "Andrea", "Mariaelena", "Matteo", "Marco", "Francesca", "Daniele", "Betta","Giulia","Michela","Alessandro","Tiziano"};
            Random random = new Random();
            int numero = random.Next(0,name.Length);
            string[] invite = new string[numero];
            int i = 0;
            if(numero == 0)
            {
                return Ok("TreMoOn");
            }
            while (i < invite.Length) 
            {
                int number = random.Next(0, name.Length);
                if (!invite.Contains(name[number]))
                {
                    invite[i] = name[number];
                    i++;
                }
            }
            return Ok(invite);
        }
    }
}
