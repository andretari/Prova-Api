﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NZWalws.API.Models.Domain;
using NZWalws.API.Models.DTO;
using NZWalws.API.Repositories.Interfaces;

namespace NZWalws.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ImagesController : ControllerBase
    {
        private readonly IImageRepository imageRepository;

        public ImagesController( IImageRepository imageRepository)
        {
            this.imageRepository = imageRepository;
        }

        // Post
        [HttpPost]
        [Route("Upload")]
        public async Task<IActionResult> Upload([FromForm] ImageUploadDto imageUploadDto)
        {
            ValidateFileUpload(imageUploadDto);
            if(ModelState.IsValid)
            {
                //User Repository to Update Image In Database
                var imgaeDomain = new Image
                {
                    File = imageUploadDto.File,
                    FileExtension = Path.GetExtension(imageUploadDto.File.FileName),
                    FileSizeInBytes = imageUploadDto.File.Length,
                    FileName = imageUploadDto.FileName,
                    FileDescription = imageUploadDto.FileDescription,
                    //FilePath verrà aggiunto dopo
                };

                await imageRepository.UploadImage(imgaeDomain);
                return Ok(imgaeDomain);
            }
            return BadRequest(ModelState);
        }

        private void ValidateFileUpload(ImageUploadDto imageUploadDto)
        {
            var allowedExtensions = new string[] { ".jpg", ".jpeg", ".png" };
            if(!allowedExtensions.Contains(Path.GetExtension(imageUploadDto.File.FileName)))
            {
                ModelState.AddModelError("file", "Unsupported file extension");
            }
            if(imageUploadDto.File.Length > 10485760)
            {
                ModelState.AddModelError("file", "file size more than 10MB, please upload a smaller size file");
            }
        }
    }
}
