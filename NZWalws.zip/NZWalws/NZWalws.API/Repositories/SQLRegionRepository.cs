﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NZWalws.API.Data;
using NZWalws.API.Models.Domain;
using NZWalws.API.Models.DTO;
using NZWalws.API.Repositories.Interfaces;

namespace NZWalws.API.Repositories
{
    public class SQLRegionRepository : IRegionRepository
    {
        private readonly NZWalksDbContext dbContext;

        public SQLRegionRepository(NZWalksDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<Region> CreateANewRegionAsync(Region region)
        {
            await dbContext.Regions.AddAsync(region);
            await dbContext.SaveChangesAsync();
            return region;
        }

        public async Task<Region?> DeleteRegionAsync(Guid id)
        {
            var region = await dbContext.Regions.FirstOrDefaultAsync(x => x.Id == id);
            if (region == null)
            {
                return null;
            }
            dbContext.Regions.Remove(region);
            await dbContext.SaveChangesAsync();
            return region;
        }

        public  async Task<List<Region>> GetAllRegionsAsync(string? colonna, string? ricerca, string? colonnaOrdinamento = null, bool ordinamento = true, int pagina = 1, int elementiPagina = 1000)
        {
            //Search
            var regionFilter = dbContext.Regions.AsQueryable();

            if (!string.IsNullOrWhiteSpace(colonna) && !string.IsNullOrWhiteSpace(ricerca))
            {
                if(colonna.Equals("Nome", StringComparison.OrdinalIgnoreCase))
                {
                     regionFilter = regionFilter.Where(x => x.Name.Contains(ricerca));
                }
            }

            //Ordinamento
            if(!string.IsNullOrWhiteSpace(colonnaOrdinamento))
            {
                if(colonnaOrdinamento.Equals("Nome", StringComparison.OrdinalIgnoreCase))
                {
                    regionFilter = ordinamento ? regionFilter.OrderBy(x => x.Name) : dbContext.Regions.OrderByDescending(x => x.Name);
                }
                else if(colonnaOrdinamento.Equals("Code", StringComparison.OrdinalIgnoreCase))
                {
                    regionFilter = ordinamento ? regionFilter.OrderBy(x => x.Code) : dbContext.Regions.OrderByDescending(x => x.Code);
                }                
            }

            //Paginazione
            var skip = (pagina - 1) * elementiPagina;

            var regions = await regionFilter.Skip(skip).Take(elementiPagina).ToListAsync();

            return regions;
        }

        public async Task<List<Region>> GetAllRegionsAsync()
        {
            return await dbContext.Regions.ToListAsync();
        }

        public async Task<Region?> GetRegionByIdAsync(Guid id)
        {        
            var region =  await dbContext.Regions.FirstOrDefaultAsync(r => r.Id == id);
            return region;
        }

        public async Task<Region?> UpdateRegionAsync(Guid id, Region updateDto)
        {
           var region = await dbContext.Regions.FirstOrDefaultAsync(x => x.Id == id);
            if (region == null)
            {
                return null;
            }

            region.Name = updateDto.Name;
            region.Code = updateDto.Code;
            region.RegoionImageUrl = updateDto.RegoionImageUrl;
            await dbContext.SaveChangesAsync();
            return region;
        }
    }
}
