﻿using Microsoft.EntityFrameworkCore;
using NZWalws.API.Data;
using NZWalws.API.Models.Domain;
using NZWalws.API.Repositories.Interfaces;

namespace NZWalws.API.Repositories
{
    public class SQLWalksRepository : IWalksRepository
    {
        private readonly NZWalksDbContext dbContext;

        public SQLWalksRepository(NZWalksDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<Walk> CreateWalkAsync(Walk walk)
        {
            await dbContext.Walks.AddAsync(walk);
            await dbContext.SaveChangesAsync();
            return walk;
        }

        public async Task<Walk?> DeleteWalkByIdAsync(Guid id)
        {
            var walk = await dbContext.Walks.FirstOrDefaultAsync(x => x.Id == id);
            if (walk == null)
            {
                return null;
            }
            dbContext.Walks.Remove(walk);
            await dbContext.SaveChangesAsync();
            return walk;
        }

        public async Task<List<Walk>> GetAllWalksAsync(string? filterOn = null, string? filterQuery = null, string? sortBy = null, bool ascending = true, int pageNumber = 1, int elementiPagina = 1000)
        {
            var walk = dbContext.Walks.Include(x => x.Difficulty).Include("Region").AsQueryable();

            //Filtraggio
            if (!string.IsNullOrWhiteSpace(filterOn) && !string.IsNullOrEmpty(filterQuery))
            {
                if (filterOn.Equals("Name", StringComparison.OrdinalIgnoreCase))
                {
                    walk = walk.Where(x => x.Name.Contains(filterQuery));
                }
            }

            //Ordinamento
            if (!string.IsNullOrWhiteSpace(sortBy))
            {
                if(sortBy.Equals("name", StringComparison.OrdinalIgnoreCase))
                {
                    walk = ascending ? walk.OrderBy( x => x.Name) : walk.OrderByDescending( x => x.Name);
                }
                else if (sortBy.Equals("Length", StringComparison.OrdinalIgnoreCase))
                {
                    walk = ascending ? walk.OrderBy(x => x.LengthInKm) : walk.OrderByDescending(x => x.LengthInKm);
                }
            }

            //Paginazione
            var skipResult = (pageNumber - 1) * elementiPagina;
            var result = await walk.Skip(skipResult).Take(elementiPagina).ToListAsync();
            if(result.Count == 0)
            {
                return null;
            }
            return await walk.Skip(skipResult).Take(elementiPagina).ToListAsync();
            //var walks = await dbContext.Walks.Include(x => x.Difficulty).Include("Region").ToListAsync();
            //return walks;
        }

        public async Task<Walk?> GetWalkByIdAsync(Guid id)
        {
            var walk = await dbContext.Walks
                .Include("Region")
                .Include("Difficulty")
                .FirstOrDefaultAsync(x => x.Id == id);
            if (walk == null)
            {
                return null;
            }
            return walk;
        }

        public async Task<Walk?> UpdateWalkByIdAsync(Guid id, Walk walk)
        {
            var walksExisting = await dbContext.Walks.FirstOrDefaultAsync(x => x.Id == id);
            if (walksExisting == null)
            {
                return null;
            }
            walksExisting.Name = walk.Name;
            walksExisting.Description = walk.Description;
            walksExisting.LengthInKm = walk.LengthInKm;
            walksExisting.WalkImageUrl = walk.WalkImageUrl;
            walksExisting.DifficultyId = walk.DifficultyId;
            walksExisting.RegionId = walk.RegionId;
            await dbContext.SaveChangesAsync();

            return walksExisting;
        }
    }
}
