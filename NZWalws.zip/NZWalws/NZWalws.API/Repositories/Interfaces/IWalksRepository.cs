﻿using Microsoft.AspNetCore.Mvc;
using NZWalws.API.Models.Domain;

namespace NZWalws.API.Repositories.Interfaces
{
    public interface IWalksRepository
    {
        public Task<Walk> CreateWalkAsync(Walk walk);
        public Task<List<Walk>> GetAllWalksAsync(string? filterOn = null, string? filterQuery = null, string? sortBy = null, bool ascending = true, int pageNumber = 1, int elementiPagina =1000);
        public Task<Walk?> GetWalkByIdAsync(Guid id);
        public Task<Walk?> UpdateWalkByIdAsync(Guid id, Walk walk);
        public Task<Walk?> DeleteWalkByIdAsync(Guid id);

    }
}
