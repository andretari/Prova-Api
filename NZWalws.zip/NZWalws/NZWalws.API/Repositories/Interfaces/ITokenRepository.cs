﻿using Microsoft.AspNetCore.Identity;

namespace NZWalws.API.Repositories.Interfaces
{
    public interface ITokenRepository
    {
       public string CreateToken(IdentityUser user, List<string> roles);
    }
}
