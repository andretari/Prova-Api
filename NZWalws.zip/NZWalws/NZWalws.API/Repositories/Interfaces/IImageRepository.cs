﻿using NZWalws.API.Models.Domain;

namespace NZWalws.API.Repositories.Interfaces
{
    public interface IImageRepository
    {
       public Task<Image> UploadImage(Image image);
    }
}
