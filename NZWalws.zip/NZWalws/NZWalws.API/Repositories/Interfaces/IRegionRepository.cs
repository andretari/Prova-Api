﻿using Microsoft.AspNetCore.Mvc;
using NZWalws.API.Models.Domain;
using NZWalws.API.Models.DTO;

namespace NZWalws.API.Repositories.Interfaces
{
    public interface IRegionRepository
    {
        public Task<List<Region>> GetAllRegionsAsync(string? colonna = null, string? ricerca = null, string? colonnaOrdinamento = null, bool ordinamento = true, int pagina = 1, int elementiPagina = 1000);
        public Task<List<Region>> GetAllRegionsAsync();
        public Task<Region?> GetRegionByIdAsync(Guid id);
        public Task<Region> CreateANewRegionAsync(Region region);
        public Task<Region?> UpdateRegionAsync(Guid id, Region updateDto);
        public Task<Region?> DeleteRegionAsync(Guid id);
    }
}
