﻿using Microsoft.AspNetCore.Mvc;
using NZWalks.Ui.Models;
using NZWalks.Ui.Models.DTOs;
using System.Linq.Expressions;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace NZWalks.Ui.Controllers
{
    public class RegionsController : Controller
    {
        private readonly IHttpClientFactory httpClientFactory;

        public RegionsController(IHttpClientFactory httpClientFactory)
        {
            this.httpClientFactory = httpClientFactory;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            List<RegionDTO> response = new List<RegionDTO>();
            try
            {
                //Get All Regions From WEB Api
                var clientFactory = httpClientFactory.CreateClient();
                var httpResponse = await clientFactory.GetAsync("https://localhost:7168/api/regions");
                //Ci assicura una risposta 200
                httpResponse.EnsureSuccessStatusCode();
                //var responseString =  await httpResponse.Content.ReadAsStringAsync();
                response.AddRange(await httpResponse.Content.ReadFromJsonAsync<IEnumerable<RegionDTO>>());

            }
            catch (Exception ex)
            {

            }
            return View(response);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(AddModel addModel)
        {
            var clientFactory = httpClientFactory.CreateClient();
            var httpRequestMessage = new HttpRequestMessage()
            {
                Method = HttpMethod.Post,
                RequestUri = new Uri("https://localhost:7168/api/regions"),
                Content = new StringContent(JsonSerializer.Serialize(addModel), Encoding.UTF8,
                "application/json")
            };
            var httpResponse = await clientFactory.SendAsync(httpRequestMessage);
            httpResponse.EnsureSuccessStatusCode();
            var response = await httpResponse.Content.ReadFromJsonAsync<RegionDTO>();
            if (response is not null)
            {
                return RedirectToAction("Index", "Regions");
            }
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> EditRegion(Guid id)
        {
            var client = httpClientFactory.CreateClient();
            var response = await client.GetFromJsonAsync<RegionDTO>($"https://localhost:7168/api/regions/{id.ToString()}");
            if (response is not null)
            {
                return View(response);
            }
            return View(id);

        }

        [HttpPost]
        public async Task<IActionResult> EditRegion(RegionDTO regionDTO)
        {
            var client = httpClientFactory.CreateClient();
            var httpRequestMessage = new HttpRequestMessage()
            {
                Method = HttpMethod.Put,
                RequestUri = new Uri($"https://localhost:7168/api/regions/{regionDTO.Id}"),
                Content = new StringContent(JsonSerializer.Serialize(regionDTO), Encoding.UTF8,
                "application/json")
            };

            var httpResponse = await client.SendAsync(httpRequestMessage);
            httpResponse.EnsureSuccessStatusCode();
            var response = await httpResponse.Content.ReadFromJsonAsync<RegionDTO>();
            if (response is not null)
            {
                return RedirectToAction("Index", "Regions");
            }
            return View();

        }

        [HttpGet]
        public async Task<IActionResult> DeleteRegion(Guid id)
        {
            var client = httpClientFactory.CreateClient();
            var response = await client.GetFromJsonAsync<RegionDTO>($"https://localhost:7168/api/regions/{id.ToString()}");
            if (response is not null)
            {
                return View(response);
            }
            return View(id);

        }

        [HttpPost]
        public async Task<IActionResult> DeleteRegion(RegionDTO region)
        {
            try
            {
                var clientFactory = httpClientFactory.CreateClient();
                var httpResponse = await clientFactory.DeleteAsync($"https://localhost:7168/api/regions/{region.Id}");
                httpResponse.EnsureSuccessStatusCode();
                return RedirectToAction("Index", "Regions");
            }
            catch(Exception ex)
            {

            }
            return View("Index");
        }
    }
}
