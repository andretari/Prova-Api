﻿using System.ComponentModel.DataAnnotations;

namespace NZWalks.Ui.Models
{
    public class AddModel
    {

        public string Code { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string? RegoionImageUrl { get; set; }
    }
}
